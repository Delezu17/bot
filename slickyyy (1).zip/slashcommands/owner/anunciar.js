const { EmbedBuilder } = require("@discordjs/builders");  // npm install @discordjs/builders discord.js
const Discord = require("discord.js");

module.exports = {
    name: "anunciar",
    description: "Envie uma mensagem dentro de uma embed",
    author: "deluzu sexo",

    run: async (client, message, args) => {

        let ryan = new Discord.EmbedBuilder()
            .setTitle("teste titulo") // Defina o titulo da embed
            .setDescription(`texto teste zzy`) // Defina a descrição da embed
            .setColor("Random") // Defina a cor da lateral da embed
            .setTimestamp()
            .setFooter({ text: '', iconURL: '' })
            .setImage("")


        message.guild.channels.cache.get('1043558041792028692').send({ embeds: [ryan] })
    }
}