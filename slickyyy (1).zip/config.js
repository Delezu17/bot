module.exports = {
    botClientID: "1042215542448214127",
    botPrefix: "s!",
    ownerID: "893191400055799808",
}