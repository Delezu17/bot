const client = require("../../index");
const { ActivityType } = require('discord.js')
const chalk = require("chalk");

module.exports = {
  name: 'ready',
  once: true,

  /**
   * @param {Client} client 
   */
  async execute(client) {

    let status = [
      `delezu xerecudo`,
      `kiylua xibilzudo`,
      `rhoizy balofo`,
      `crowley u virgi`,
      `estou em desenvolvimento.`,
      `atualmente com ${client.users.cache.size.toLocaleString('en-US')} usuarios`,
    ],
      i = 0
    setInterval(() => {
      client.user.setActivity(`${status[i++ % status.length]}`, {
        type: ActivityType.Playing
      })
    }, 1000);
    console.log(chalk.blueBright(`Slicky acordou!`));
  }
}